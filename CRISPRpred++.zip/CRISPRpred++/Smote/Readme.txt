1. Run "featurization.R". Select the file "Supplementary File1" when prompted. The generated features are saved in "featuredataAll" variable. 
Run write.csv(featuredataAll, "filename") to save generated data to desired file.It is already provide in "onTargetFinalData.csv" file for direct use.
  

2. Run "testingExperiments.R" to make predictions for leave one gene out method. In this file
  line 46: change threshold value to .1265
  line 114: final predictions are saved in "final_predictions.csv" file


3. Run "calculateclassificationscore.R" to get the values of area under ROC and PR-curves. 
   Choose file "final_predictions.csv"
   The accuracy, area under ROC and PR-curves are saved on features variable. Print it to see the results. 


[ The feature importance contaninning file is already given named "randomForestFeaturesCopy.csv".
  Supplementary File1.csv contains the gene sequences.
  sortedontargetresults.csv contains the genes sorted chronologically. 
  best predictions are given in "predictions_cost_13_percent.csv" file.
 ]